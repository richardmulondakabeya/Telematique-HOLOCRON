# HOLOCRON — audit du module de communication

HOLOCRON est un prototype web autonome de communication locale : messagerie, appels audio/vidéo WebRTC et partage de fichiers. Le serveur du prototype est toujours démarré par `npm start`. Cet audit vérifie les fonctionnalités attendues, décrit les limites constatées et résume les tests exécutables.

**État au 20 novembre 2026 :** l’interface de messagerie HOLOCRON et les principaux parcours serveur ont des tests d’intégration. Cela ne constitue pas une validation des appels entre appareils physiques ni une certification de préparation à la production.

## Démarrer

Prérequis : Node.js 20 ou plus récent. Aucune dépendance npm n’est nécessaire à l’exécution.

```sh
npm start
```

Ouvrir `http://localhost:3000` sur le serveur. L’application écoute sur toutes les interfaces réseau ; depuis un autre poste, utiliser `http://ADRESSE_IP_DU_SERVEUR:3000` et autoriser le port TCP `3000` dans le pare-feu. `PORT` permet de choisir le port.

Sous Windows, `Ouvrir-Lien.bat` démarre le serveur et ouvre l’application. Pour HTTPS, le script `start-https.ps1` et le certificat fourni permettent un déploiement local ; le certificat doit être approuvé par les appareils clients. Ne partagez jamais `lien-https.pfx` ni son mot de passe.

Les appels caméra/micro exigent une origine sécurisée : HTTPS sur les appareils distants, ou `localhost` sur l’ordinateur serveur. La configuration ICE est contrôlée par `ICE_SERVERS_JSON`. Par défaut, Lien utilise `stun:stun.l.google.com:19302`, mais ne fournit pas de relais TURN.

## Résultat de l’audit

| Module attendu | Présence | Résultat et limites |
|---|---|---|
| Messagerie instantanée | **Présent** | L’accueil met en avant les contacts en ligne et hors ligne. La recherche filtre les contacts et groupes et peut rechercher dans les messages accessibles. Conversations privées, salon général, groupes et actions d’appel ; diffusion temps réel WebSocket, historique local et accusés de réception/lecture en privé. Pas de fils, réactions, mentions ni édition/suppression. |
| VoIP audio | **Présent dans le code** | Appels WebRTC avec signalisation WebSocket, invitations, états d’appel, coupure micro et libération des pistes à la fin. La transmission audio réelle entre deux appareils n’a pas été validée pendant cet audit. |
| Visioconférence | **Présent dans le code** | Flux caméra WebRTC, appels de groupe en maillage et commandes caméra/micro. Pas de partage d’écran ni d’enregistrement. La qualité, la compatibilité des appareils et les appels réels restent à tester. |
| Partage de fichiers | **Présent et testé** | Envoi dans les salons, groupes et conversations autorisés ; téléchargement protégé par session et appartenance au salon ; limite de 50 Mo ; prise en charge des requêtes HTTP Range. |
| Photos | **Présent et amélioré** | Formats JPEG, PNG, GIF, WebP, AVIF et BMP servis avec leur type MIME et affichés en aperçu dans le fil. SVG n’est pas pris en charge en aperçu. |
| Audio/vidéo joints et vocaux | **Présent** | Les fichiers audio et vidéo reconnus s’affichent avec un lecteur du navigateur ; un vocal peut être enregistré jusqu’à 60 secondes. Les autres pièces jointes sont proposées en téléchargement. |
| Utilisateurs et présence | **Présent, rudimentaire** | Création de compte/connexion, annuaire, présence, conversation directe avec les comptes hors ligne et demandes d’adhésion aux groupes publics soumises à approbation. Les comptes résident dans un fichier JSON local ; pas d’administration, de rôles avancés, de vérification d’adresse, de récupération de mot de passe ni de fédération avec un fournisseur d’identité. |
| Fonctionnement local | **Présent, sous conditions** | Serveur Node.js unique joignable sur le réseau local. Le mode HTTP par défaut ne chiffre pas les identifiants ; HTTPS est nécessaire pour les appareils distants et recommandé sur tout réseau non fiable. |

### Ce que les tests établissent — et ce qu’ils n’établissent pas

`npm test` lance une suite d’intégration avec un serveur temporaire et un répertoire de données isolé. Les tests vérifient :

- le refus des API protégées sans session, ainsi que l’inscription, la validation, les doublons et l’authentification ;
- les autorisations de membres et de créateurs pour les groupes ;
- les demandes d’accès aux groupes publics, le refus par un membre non créateur, l’approbation et le refus par le créateur ;
- la recherche authentifiée dans l’historique des messages accessibles ;
- l’envoi et l’accès contrôlé à une image, le type MIME, le téléchargement partiel HTTP Range, les fichiers vides et les pièces jointes après suppression d’un groupe ;
- la diffusion WebSocket en temps réel des messages publics et privés, les accusés de lecture, la présence et le transport des invitations de visioconférence.
- un scénario simultané isolé à sept comptes fictifs : échange privé entre deux comptes, messages et photo partagée dans un groupe de cinq, téléchargements autorisés/refusés, signalisation d’un appel audio privé et des dix liaisons d’un maillage vidéo à cinq participants.

La simulation automate les messages, pièces jointes et échanges de **signalisation** avec des descriptions SDP fictives ; elle ne lance pas de navigateur et ne valide ni une négociation ICE réelle ni le média audio/vidéo. Elle n’utilise ni micro/caméra physiques, ni deux téléphones, ni deux réseaux. Les appels doivent encore être testés sur le même Wi-Fi puis sur des réseaux distincts, avec les permissions navigateur et un serveur TURN. Sans TURN, certains NAT et pare-feu empêcheront la connexion.

### Historique et déconnexion

Chaque nouveau compte reçoit une date de création. Le serveur ne renvoie à ce compte que les messages dont l’horodatage est ultérieur à cette date, y compris dans une conversation privée. Il peut néanmoins commencer une conversation avec n’importe quel compte existant depuis **Nouveau message**, que ce compte soit actuellement en ligne ou non. Les membres qui ont déjà un compte conservent leurs historiques.

Lors d’une coupure WebSocket ou d’une déconnexion volontaire, le fil affiché est retiré de l’interface et la reconnexion recharge uniquement les messages autorisés au compte. La déconnexion volontaire révoque également la session côté serveur. Ce nettoyage porte sur la copie affichée en mémoire dans la page : il ne supprime pas les historiques stockés, ce qui évite d’effacer les conversations des autres personnes. Le navigateur ne met pas les réponses d’API privées en cache persistant côté application.

## Architecture et limites de stabilité

- Les comptes, groupes, messages et métadonnées des pièces jointes sont conservés dans `users.json`, `groups.json`, `messages.json` et `attachments.json`. Les fichiers sont dans `uploads/`. Ce stockage local n’est ni transactionnel ni adapté à plusieurs processus concurrents.
- Les sessions de connexion et les connexions en ligne sont en mémoire : un redémarrage invalide les sessions et interrompt les appels. L’application fonctionne en processus unique, sans réplication ni mécanisme de reprise.
- Les écritures synchrones JSON peuvent bloquer le serveur sous charge. Aucun quota utilisateur, antivirus, chiffrement des fichiers au repos, sauvegarde automatique ou politique de rétention n’est fourni.
- En appels de groupe, les navigateurs forment un maillage WebRTC. La charge réseau et CPU augmente avec le nombre de participants. Un serveur TURN est configurable ; aucun relais média central ou service de conférence évolutif n’est inclus.
- Le port TCP du serveur transporte HTTP(S) et la signalisation WebSocket. WebRTC négocie séparément le transport média avec ICE ; ouvrir seulement le port TCP ne garantit pas les appels.

**Conclusion :** HOLOCRON démontre les quatre briques demandées et convient à un prototype pédagogique sur réseau local. Il ne faut pas encore le présenter comme un système stable, doté d’un annuaire riche ou prêt pour une exploitation réelle. Les principaux manques sont l’intégration à un fournisseur d’identité central, la gestion/administration des comptes, un stockage robuste et la validation des appels réels sur plusieurs réseaux.

## Avis sur Nextcloud Talk pour Holocron

Nextcloud Talk est une application du serveur Nextcloud, pas un service autonome à importer directement dans le serveur Node.js de Lien. Elle fournit déjà messagerie, appels audio/vidéo, conversations de groupe et partage des fichiers Nextcloud. Elle réutilise donc l’annuaire et le stockage d’un Nextcloud déployé.

**Docker n’est pas une obligation de Talk.** L’application peut être installée depuis l’App Store sur une instance Nextcloud existante. Docker Compose est toutefois une façon pratique de rendre reproductible un nouvel environnement : il faut tout de même exploiter Nextcloud Server et ses composants de stockage/base de données, sécuriser l’accès, gérer les comptes et configurer le réseau. Selon les NAT et pare-feu, un serveur TURN reste également nécessaire.

Pour Holocron, l’approche la plus efficace est de traiter Nextcloud comme le service de communication et d’identité, puis de relier Holocron à cette instance via les API documentées et/ou une authentification commune prise en charge. Il vaut mieux éviter de copier l’application Spreed dans Lien ou de réimplémenter son protocole. Si Holocron doit rester autonome sans serveur Nextcloud, Lien peut servir de base de démonstration, mais il faudra planifier les manques ci-dessus avant d’en faire un module stable.

**Décision de faisabilité :** faisable si le projet accepte de déployer et d’administrer Nextcloud ; ce n’est pas un simple ajout d’API à l’application actuelle. Avant de choisir, faire un essai technique isolé : démarrer Nextcloud + Talk, créer deux comptes, vérifier les appels et les pièces jointes sur le réseau cible, puis valider le mécanisme de connexion Holocron et les droits d’accès aux fichiers.

Références officielles consultées :

- [Dépôt Nextcloud Talk (spreed)](https://github.com/nextcloud/spreed) — fonctionnalités, installation et documentation officielle.
- [Documentation développeur et API Talk](https://nextcloud-talk.readthedocs.io/en/latest/) — API, exigences et administration.
- [Guide utilisateur Nextcloud Talk](https://docs.nextcloud.com/server/latest/user_manual/en/talk/index.html).

## Tests

```sh
npm test
```

La suite utilise uniquement les modules intégrés à Node.js. Elle démarre le serveur sur un port temporaire, utilise `DATA_DIR` pour isoler les données et supprime ce répertoire à la fin. Les données réelles du dossier du projet ne sont pas utilisées par les tests.

## Maquette et parcours de messagerie

La maquette statique est disponible dans [holocron-messenger-mockup.svg](./holocron-messenger-mockup.svg) et l’identité graphique dans [holocron-logo.svg](./holocron-logo.svg). L’interface utilisable se trouve dans `index.html` et `messenger.css`.

- **Nouvelle conversation** ouvre l’annuaire et crée un fil privé dès qu’un compte est choisi, même s’il est hors ligne.
- L’accueil affiche les contacts en ligne et hors ligne. La barre de recherche filtre les noms et groupes ; appuyer sur Entrée recherche le contenu des conversations auxquelles le compte a accès.
- **Créer un groupe** offre un groupe privé sur invitation ou public découvrable. Pour un groupe public, une demande doit être approuvée par le créateur avant que les messages deviennent accessibles. Les créateurs peuvent changer la visibilité d’un groupe et traiter les demandes depuis **Demandes d’accès**.
- **Personnaliser le thème** permet de choisir les palettes Forêt, Océan, Lavande ou Minuit ainsi qu’un arrière-plan assorti ; le choix est conservé dans le navigateur.
- Les boutons d’appel audio et vidéo restent dans l’en-tête du fil actif. L’ajout de fichier et la saisie restent dans la zone de rédaction.
