const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { once } = require('node:events');
const { test } = require('node:test');

function clientFrame(value, opcode = 1) {
  const body = Buffer.from(typeof value === 'string' ? value : JSON.stringify(value));
  const mask = crypto.randomBytes(4);
  let header;
  if (body.length < 126) {
    header = Buffer.from([0x80 | opcode, 0x80 | body.length]);
  } else {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 0xfe;
    header.writeUInt16BE(body.length, 2);
  }
  const maskedBody = Buffer.from(body);
  for (let i = 0; i < maskedBody.length; i++) maskedBody[i] ^= mask[i % mask.length];
  return Buffer.concat([header, mask, maskedBody]);
}

function connectWebSocket(port, cookie) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ host: '127.0.0.1', port });
    const key = crypto.randomBytes(16).toString('base64');
    let buffer = Buffer.alloc(0);
    let handshaken = false;
    let settled = false;
    const messages = [];
    const waiters = [];

    function processFrames() {
      if (!handshaken) {
        const end = buffer.indexOf('\r\n\r\n');
        if (end < 0) return;
        const response = buffer.subarray(0, end).toString('utf8');
        buffer = buffer.subarray(end + 4);
        if (!response.startsWith('HTTP/1.1 101 ')) {
          reject(new Error(`WebSocket handshake failed: ${response.split('\r\n')[0]}`));
          socket.destroy();
          return;
        }
        handshaken = true;
      }

      while (buffer.length >= 2) {
        const opcode = buffer[0] & 0x0f;
        let length = buffer[1] & 0x7f;
        let offset = 2;
        if (length === 126) {
          if (buffer.length < 4) return;
          length = buffer.readUInt16BE(2);
          offset = 4;
        } else if (length === 127) {
          if (buffer.length < 10) return;
          const extendedLength = buffer.readBigUInt64BE(2);
          if (extendedLength > 65536n) throw new Error('Unexpected oversized WebSocket frame');
          length = Number(extendedLength);
          offset = 10;
        }
        if (buffer.length < offset + length) return;
        const body = buffer.subarray(offset, offset + length);
        buffer = buffer.subarray(offset + length);
        if (opcode === 9) {
          socket.write(clientFrame(body, 10));
          continue;
        }
        if (opcode !== 1) continue;
        const message = JSON.parse(body.toString('utf8'));
        const waiterIndex = waiters.findIndex(waiter => waiter.predicate(message));
        if (waiterIndex >= 0) waiters.splice(waiterIndex, 1)[0].resolve(message);
        else messages.push(message);
      }
    }

    socket.on('connect', () => {
      socket.write([
        'GET /ws HTTP/1.1',
        `Host: 127.0.0.1:${port}`,
        'Upgrade: websocket',
        'Connection: Upgrade',
        `Sec-WebSocket-Key: ${key}`,
        'Sec-WebSocket-Version: 13',
        `Cookie: ${cookie}`,
        '',
        ''
      ].join('\r\n'));
    });
    socket.on('data', chunk => {
      try {
        buffer = Buffer.concat([buffer, chunk]);
        processFrames();
        if (handshaken && !settled) {
          settled = true;
          resolve({
            send(message) {
              socket.write(clientFrame(message));
            },
            waitFor(predicate, timeout = 3000) {
              const existingIndex = messages.findIndex(predicate);
              if (existingIndex >= 0) return Promise.resolve(messages.splice(existingIndex, 1)[0]);
              return new Promise((resolveMessage, rejectMessage) => {
                const timer = setTimeout(() => {
                  const index = waiters.findIndex(waiter => waiter.resolve === resolveMessage);
                  if (index >= 0) waiters.splice(index, 1);
                  rejectMessage(new Error('Timed out waiting for WebSocket message'));
                }, timeout);
                waiters.push({
                  predicate,
                  resolve(message) {
                    clearTimeout(timer);
                    resolveMessage(message);
                  }
                });
              });
            },
            close() {
              socket.destroy();
            }
          });
        }
      } catch (error) {
        reject(error);
        socket.destroy();
      }
    });
    socket.on('error', error => {
      if (!settled) reject(error);
    });
    socket.on('close', () => {
      if (!settled) reject(new Error('WebSocket closed before handshake completed'));
    });
  });
}

async function reservePort() {
  const listener = net.createServer();
  listener.listen(0, '127.0.0.1');
  await once(listener, 'listening');
  const port = listener.address().port;
  await new Promise((resolve, reject) => listener.close(error => error ? reject(error) : resolve()));
  return port;
}

async function startServer(port, dataDir) {
  const child = spawn(process.execPath, ['server.js'], {
    cwd: path.resolve(__dirname, '..'),
    env: { ...process.env, PORT: String(port), DATA_DIR: dataDir },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  child.stdout.on('data', chunk => { output += chunk; });
  child.stderr.on('data', chunk => { output += chunk; });
  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Server exited during startup:\n${output}`);
    try {
      const response = await fetch(`http://127.0.0.1:${port}/health`);
      if (response.ok) return child;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  child.kill();
  throw new Error(`Server did not become ready:\n${output}`);
}

async function request(baseUrl, route, { cookie, ...options } = {}) {
  const headers = new Headers(options.headers);
  if (cookie) headers.set('cookie', cookie);
  const response = await fetch(`${baseUrl}${route}`, { ...options, headers });
  let data;
  try {
    data = await response.json();
  } catch {
    data = await response.text();
  }
  return { response, data };
}

function sessionCookie(response) {
  const cookie = response.headers.get('set-cookie');
  assert.ok(cookie, 'login or registration should create a session cookie');
  return cookie.split(';', 1)[0];
}

test('local communication modules: authentication, groups, files and live signaling', async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'lien-integration-'));
  const port = await reservePort();
  const baseUrl = `http://127.0.0.1:${port}`;
  let server;
  let groupId;
  let pendingGroupId;
  const sockets = [];

  try {
    server = await startServer(port, dataDir);

    await t.test('protected APIs reject anonymous requests', async () => {
      for (const route of ['/api/ice-config', '/api/users', '/api/groups', '/api/groups/requests', '/api/messages/search?q=test']) {
        const { response } = await request(baseUrl, route);
        assert.equal(response.status, 401, route);
      }
      const upload = await request(baseUrl, '/api/uploads', {
        method: 'POST',
        headers: { 'x-room': 'general', 'x-file-name': 'photo.png' },
        body: Buffer.from('image')
      });
      assert.equal(upload.response.status, 401);
    });

    const passwordA = crypto.randomBytes(18).toString('base64url');
    const passwordB = crypto.randomBytes(18).toString('base64url');
    const passwordC = crypto.randomBytes(18).toString('base64url');
    const accountA = await request(baseUrl, '/api/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'Camille Martin', email: 'camille.integration@example.invalid', password: passwordA })
    });
    assert.equal(accountA.response.status, 200);
    const cookieA = sessionCookie(accountA.response);

    const invalidRegistration = await request(baseUrl, '/api/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'C', email: 'not-an-email', password: 'short' })
    });
    assert.equal(invalidRegistration.response.status, 400);

    const duplicateRegistration = await request(baseUrl, '/api/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'Camille Martin', email: 'camille.integration@example.invalid', password: passwordA })
    });
    assert.equal(duplicateRegistration.response.status, 409);

    const failedLogin = await request(baseUrl, '/api/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email: 'camille.integration@example.invalid', password: 'incorrect' })
    });
    assert.equal(failedLogin.response.status, 401);

    const accountB = await request(baseUrl, '/api/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'Alex Bernard', email: 'alex.bernard@example.invalid', password: passwordB })
    });
    assert.equal(accountB.response.status, 200);
    const cookieB = sessionCookie(accountB.response);

    const accountC = await request(baseUrl, '/api/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'Morgan Leroy', email: 'morgan.leroy@example.invalid', password: passwordC })
    });
    assert.equal(accountC.response.status, 200);
    const cookieC = sessionCookie(accountC.response);

    const goodLogin = await request(baseUrl, '/api/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email: 'camille.integration@example.invalid', password: passwordA })
    });
    assert.equal(goodLogin.response.status, 200);
    const loginCookie = sessionCookie(goodLogin.response);
    const currentUser = await request(baseUrl, '/api/me', { cookie: loginCookie });
    assert.equal(currentUser.data.user.name, 'Camille Martin');
    assert.equal(currentUser.response.headers.get('cache-control'), 'no-store');
    assert.deepEqual((await request(baseUrl, '/api/ice-config', { cookie: cookieA })).data.iceServers[0].urls, 'stun:stun.l.google.com:19302');
    assert.equal((await request(baseUrl, '/api/users', { cookie: cookieA })).data.users.length, 2);
    const logout = await request(baseUrl, '/api/logout', { cookie: loginCookie, method: 'POST' });
    assert.equal(logout.response.status, 200);
    assert.match(logout.response.headers.get('set-cookie'), /Max-Age=0/);
    assert.equal((await request(baseUrl, '/api/me', { cookie: loginCookie })).data.user, null);

    await t.test('groups enforce membership and creator-only deletion', async () => {
      const publicCreated = await request(baseUrl, '/api/groups', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Communauté ouverte', memberIds: [], visibility: 'public' })
      });
      assert.equal(publicCreated.response.status, 201);
      assert.equal(publicCreated.data.group.visibility, 'public');
      const publicId = publicCreated.data.group.id;
      assert.equal((await request(baseUrl, '/api/groups/discover', { cookie: cookieB })).data.groups[0].id, publicId);
      const requestAccess = await request(baseUrl, `/api/groups/${publicId}/join`, { cookie: cookieB, method: 'POST' });
      assert.equal(requestAccess.response.status, 200);
      assert.equal(requestAccess.data.status, 'pending');
      assert.equal((await request(baseUrl, '/api/groups', { cookie: cookieB })).data.groups.some(group => group.id === publicId), false);
      assert.equal((await request(baseUrl, '/api/groups/discover', { cookie: cookieB })).data.groups[0].requestPending, true);
      assert.equal((await request(baseUrl, `/api/groups/${publicId}/requests/${accountB.data.user.id}/approve`, { cookie: cookieC, method: 'POST' })).response.status, 403);
      const pendingRequests = await request(baseUrl, '/api/groups/requests', { cookie: cookieA });
      assert.ok(pendingRequests.data.requests.some(item => item.groupId === publicId && item.userId === accountB.data.user.id));
      assert.equal((await request(baseUrl, `/api/groups/${publicId}/requests/${accountB.data.user.id}/approve`, { cookie: cookieA, method: 'POST' })).data.status, 'approved');
      assert.ok((await request(baseUrl, '/api/groups', { cookie: cookieB })).data.groups.some(group => group.id === publicId));
      assert.equal((await request(baseUrl, `/api/groups/${publicId}`, {
        cookie: cookieB, method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visibility: 'private' })
      })).response.status, 403);
      assert.equal((await request(baseUrl, `/api/groups/${publicId}`, {
        cookie: cookieA, method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visibility: 'private' })
      })).data.group.visibility, 'private');
      assert.equal((await request(baseUrl, `/api/groups/${publicId}`, {
        cookie: cookieA, method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ visibility: 'public' })
      })).data.group.visibility, 'public');
      assert.equal((await request(baseUrl, '/api/groups/discover', { cookie: cookieB })).data.groups.some(group => group.id === publicId), false);

      const rejectedGroup = await request(baseUrl, '/api/groups', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Groupe sur demande', memberIds: [], visibility: 'public' })
      });
      const rejectedGroupId = rejectedGroup.data.group.id;
      await request(baseUrl, `/api/groups/${rejectedGroupId}/join`, { cookie: cookieC, method: 'POST' });
      assert.equal((await request(baseUrl, `/api/groups/${rejectedGroupId}/requests/${accountC.data.user.id}/reject`, { cookie: cookieA, method: 'POST' })).data.status, 'rejected');
      assert.equal((await request(baseUrl, '/api/groups', { cookie: cookieC })).data.groups.some(group => group.id === rejectedGroupId), false);
      const pendingGroup = await request(baseUrl, '/api/groups', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Accès sur approbation', memberIds: [], visibility: 'public' })
      });
      pendingGroupId = pendingGroup.data.group.id;
      assert.equal((await request(baseUrl, `/api/groups/${pendingGroupId}/join`, { cookie: cookieC, method: 'POST' })).data.status, 'pending');

      const invalidGroup = await request(baseUrl, '/api/groups', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Groupe sans membre', memberIds: [] })
      });
      assert.equal(invalidGroup.response.status, 400);

      const created = await request(baseUrl, '/api/groups', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Projet Holocron', memberIds: [accountB.data.user.id] })
      });
      assert.equal(created.response.status, 201);
      const group = created.data.group;
      groupId = group.id;
      assert.ok((await request(baseUrl, '/api/groups', { cookie: cookieB })).data.groups.some(memberGroup => memberGroup.id === group.id));
      assert.equal((await request(baseUrl, `/api/groups/${group.id}`, { cookie: cookieB, method: 'DELETE' })).response.status, 403);
      assert.equal((await request(baseUrl, `/api/groups/${group.id}`, { cookie: cookieC, method: 'DELETE' })).response.status, 403);
    });

    await t.test('file exchange preserves image MIME, range reads and room permissions', async () => {
      const groupRoom = `group:${groupId}`;
      const outsiderUpload = await request(baseUrl, '/api/uploads', {
        cookie: cookieC,
        method: 'POST',
        headers: { 'content-type': 'image/png', 'x-file-name': 'photo.png', 'x-room': groupRoom },
        body: Buffer.from('not allowed')
      });
      assert.equal(outsiderUpload.response.status, 403);

      const emptyUpload = await request(baseUrl, '/api/uploads', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'image/png', 'x-file-name': 'empty.png', 'x-room': groupRoom },
        body: Buffer.alloc(0)
      });
      assert.equal(emptyUpload.response.status, 400);

      const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/r7sAAAAASUVORK5CYII=', 'base64');
      const upload = await request(baseUrl, '/api/uploads', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'image/png', 'x-file-name': 'photo.png', 'x-room': groupRoom },
        body: png
      });
      assert.equal(upload.response.status, 201);
      assert.equal(upload.data.attachment.mime, 'image/png');

      const forbiddenDownload = await request(baseUrl, `/api/files/${upload.data.attachment.id}`, { cookie: cookieC });
      assert.equal(forbiddenDownload.response.status, 404);
      const download = await fetch(`${baseUrl}/api/files/${upload.data.attachment.id}`, { headers: { cookie: cookieB } });
      assert.equal(download.status, 200);
      assert.equal(download.headers.get('content-type'), 'image/png');
      assert.match(download.headers.get('content-disposition'), /^inline;/);
      assert.deepEqual(Buffer.from(await download.arrayBuffer()), png);

      const range = await fetch(`${baseUrl}/api/files/${upload.data.attachment.id}`, {
        headers: { cookie: cookieB, range: 'bytes=0-7' }
      });
      assert.equal(range.status, 206);
      assert.equal(range.headers.get('content-range'), `bytes 0-7/${png.length}`);
      assert.equal((await range.arrayBuffer()).byteLength, 8);

      assert.equal((await request(baseUrl, `/api/groups/${groupId}`, { cookie: cookieA, method: 'DELETE' })).response.status, 200);
      assert.equal((await request(baseUrl, `/api/files/${upload.data.attachment.id}`, { cookie: cookieB })).response.status, 404);
    });

    await t.test('WebSocket chat, receipts, and call signaling reach peers in real time', async () => {
      const clientA = await connectWebSocket(port, cookieA);
      const clientB = await connectWebSocket(port, cookieB);
      const clientC = await connectWebSocket(port, cookieC);
      sockets.push(clientA, clientB, clientC);
      clientA.send({ type: 'join', room: 'lobby' });
      const welcomeA = await clientA.waitFor(message => message.type === 'welcome');
      assert.equal(welcomeA.room, 'lobby');
      assert.equal(welcomeA.messages.length, 0, 'the contacts landing room must not load general messages');
      clientB.send({ type: 'join', room: 'lobby' });
      const welcomeB = await clientB.waitFor(message => message.type === 'welcome');
      clientC.send({ type: 'join', room: 'lobby' });
      const welcomeC = await clientC.waitFor(message => message.type === 'welcome');
      assert.equal(welcomeA.users.length, 1);
      assert.equal(welcomeB.users.length, 2);
      assert.equal(welcomeC.room, 'lobby');
      const presence = await clientA.waitFor(message => message.type === 'presence' && message.users.some(user => user.userId === accountC.data.user.id));
      assert.equal(presence.users.length, 3);
      clientC.send({ type: 'switch-room', room: `group:${pendingGroupId}` });
      await assert.rejects(clientC.waitFor(message => message.type === 'welcome' && message.room === `group:${pendingGroupId}`, 150), /Timed out/);
      clientA.send({ type: 'switch-room', room: 'general' });
      await clientA.waitFor(message => message.type === 'welcome' && message.room === 'general');
      clientB.send({ type: 'switch-room', room: 'general' });
      await clientB.waitFor(message => message.type === 'welcome' && message.room === 'general');

      clientA.send({ type: 'chat', text: 'Message temps réel' });
      const [sentA, sentB] = await Promise.all([
        clientA.waitFor(message => message.type === 'message' && message.message.text === 'Message temps réel'),
        clientB.waitFor(message => message.type === 'message' && message.message.text === 'Message temps réel')
      ]);
      assert.equal(sentA.message.sender, 'Camille Martin');
      assert.equal(sentB.message.room, 'general');
      const messageSearch = await request(baseUrl, '/api/messages/search?q=temps%20r%C3%A9el', { cookie: cookieA });
      assert.ok(messageSearch.data.results.some(message => message.text === 'Message temps réel' && message.room === 'general'));

      const passwordNew = crypto.randomBytes(18).toString('base64url');
      const newAccount = await request(baseUrl, '/api/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Noah Petit', email: 'noah.petit@example.invalid', password: passwordNew })
      });
      assert.equal(newAccount.response.status, 200);
      assert.equal((await clientA.waitFor(message => message.type === 'directory-update')).type, 'directory-update');
      const cookieNew = sessionCookie(newAccount.response);
      const directory = await request(baseUrl, '/api/users', { cookie: cookieNew });
      assert.deepEqual(new Set(directory.data.users.map(user => user.id)), new Set([accountA.data.user.id, accountB.data.user.id, accountC.data.user.id]));

      const newClient = await connectWebSocket(port, cookieNew);
      sockets.push(newClient);
      newClient.send({ type: 'join', room: 'general' });
      const welcomeNew = await newClient.waitFor(message => message.type === 'welcome');
      assert.equal(welcomeNew.messages.length, 0, 'new accounts must not receive earlier room messages');
      newClient.send({ type: 'switch-room', withUser: accountC.data.user.id });
      const newDirectWelcome = await newClient.waitFor(message => message.type === 'welcome' && message.room.startsWith('dm:'));
      assert.equal(newDirectWelcome.messages.length, 0);
      newClient.send({ type: 'chat', text: 'Première conversation de Noah' });
      const ownConversation = await newClient.waitFor(message => message.type === 'message' && message.message.text === 'Première conversation de Noah');
      assert.equal(ownConversation.message.sender, 'Noah Petit');

      const simulationUsers = [];
      for (const [name, email] of [
        ['Lina Moreau', 'lina.moreau@example.invalid'],
        ['Hugo Petit', 'hugo.petit@example.invalid'],
        ['Ines Laurent', 'ines.laurent@example.invalid']
      ]) {
        const registration = await request(baseUrl, '/api/register', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ name, email, password: crypto.randomBytes(18).toString('base64url') })
        });
        assert.equal(registration.response.status, 200);
        simulationUsers.push({
          user: registration.data.user,
          cookie: sessionCookie(registration.response),
          name
        });
      }

      const returningClient = await connectWebSocket(port, cookieA);
      sockets.push(returningClient);
      returningClient.send({ type: 'join', room: 'general' });
      const returningWelcome = await returningClient.waitFor(message => message.type === 'welcome');
      assert.ok(returningWelcome.messages.some(message => message.text === 'Message temps réel'), 'existing accounts must retain their conversation history');

      const directRoom = `dm:${[accountA.data.user.id, accountB.data.user.id].sort().join(':')}`;
      clientA.send({ type: 'switch-room', withUser: accountB.data.user.id });
      assert.equal((await clientA.waitFor(message => message.type === 'welcome')).room, directRoom);
      clientB.send({ type: 'switch-room', withUser: accountA.data.user.id });
      await clientB.waitFor(message => message.type === 'welcome' && message.room === directRoom);
      clientA.send({ type: 'chat', text: 'Message privé' });
      const directMessage = await clientB.waitFor(message => message.type === 'message' && message.message.text === 'Message privé');
      clientB.send({ type: 'receipt', messageId: directMessage.message.id, room: directRoom, status: 'read' });
      const receipt = await clientA.waitFor(message => message.type === 'message' && message.message.receipt);
      assert.equal(receipt.message.status, 'read');

      clientA.send({ type: 'call-state', mode: 'video' });
      const callRoster = await clientB.waitFor(message => message.type === 'users' && message.users.some(user => user.call === 'video'));
      assert.ok(callRoster.users.some(user => user.call === 'video'));
      clientA.send({ type: 'call-invite', to: welcomeB.selfId, mode: 'video' });
      const invite = await clientB.waitFor(message => message.type === 'signal' && message.data.invite);
      assert.equal(invite.data.mode, 'video');
      clientB.send({ type: 'signal', to: welcomeA.selfId, data: { accepted: true } });
      assert.equal((await clientA.waitFor(message => message.type === 'signal' && message.data.accepted)).from, welcomeB.selfId);
      clientA.send({ type: 'call-state', mode: null });

      const groupMembers = [accountB.data.user, accountC.data.user, newAccount.data.user, simulationUsers[0].user];
      const simulationGroup = await request(baseUrl, '/api/groups', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: 'Simulation HOLOCRON', memberIds: groupMembers.map(user => user.id) })
      });
      assert.equal(simulationGroup.response.status, 201);
      assert.equal(simulationGroup.data.group.memberIds.length, 5);
      const simulationRoom = `group:${simulationGroup.data.group.id}`;
      const groupParticipants = [
        { user: accountA.data.user, cookie: cookieA, name: accountA.data.user.name },
        { user: accountB.data.user, cookie: cookieB, name: accountB.data.user.name },
        { user: accountC.data.user, cookie: cookieC, name: accountC.data.user.name },
        { user: newAccount.data.user, cookie: cookieNew, name: newAccount.data.user.name },
        simulationUsers[0]
      ];
      const groupClients = [];
      for (const participant of groupParticipants) {
        const client = await connectWebSocket(port, participant.cookie);
        sockets.push(client);
        client.send({ type: 'join', room: simulationRoom });
        const welcome = await client.waitFor(message => message.type === 'welcome' && message.room === simulationRoom);
        groupClients.push({ ...participant, client, selfId: welcome.selfId });
      }
      for (const participant of simulationUsers.slice(1)) {
        const client = await connectWebSocket(port, participant.cookie);
        sockets.push(client);
        client.send({ type: 'join', room: 'lobby' });
        await client.waitFor(message => message.type === 'welcome' && message.room === 'lobby');
      }

      const pairMessage = 'Simulation simultanée - message privé';
      clientA.send({ type: 'chat', text: pairMessage });
      const pairDelivery = clientB.waitFor(message => message.type === 'message' && message.message.text === pairMessage);
      const groupMessages = groupClients.map((participant, index) => {
        const text = `Simulation groupe - ${participant.name} - ${index + 1}`;
        participant.client.send({ type: 'chat', text });
        return text;
      });
      const [pairReceived, ...groupDeliveries] = await Promise.all([
        pairDelivery,
        ...groupClients.flatMap(participant => groupMessages.map(text =>
          participant.client.waitFor(message => message.type === 'message' && message.message.text === text)))
      ]);
      assert.equal(pairReceived.message.text, pairMessage);
      assert.equal(groupDeliveries.length, 25, 'each group member must receive all five messages');

      const directUpload = await request(baseUrl, '/api/uploads', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'text/plain', 'x-file-name': 'echange-prive.txt', 'x-room': directRoom },
        body: Buffer.from('Fichier partagé dans la conversation privée.')
      });
      assert.equal(directUpload.response.status, 201);
      const photoBytes = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/r7sAAAAASUVORK5CYII=', 'base64');
      const groupUpload = await request(baseUrl, '/api/uploads', {
        cookie: cookieA,
        method: 'POST',
        headers: { 'content-type': 'image/png', 'x-file-name': 'photo-groupe.png', 'x-room': simulationRoom },
        body: photoBytes
      });
      assert.equal(groupUpload.response.status, 201);
      assert.equal((await groupClients[1].client.waitFor(message =>
        message.type === 'message' && message.message.attachment?.id === groupUpload.data.attachment.id
      )).message.attachment.name, 'photo-groupe.png');
      const directDownload = await fetch(`${baseUrl}/api/files/${directUpload.data.attachment.id}`, { headers: { cookie: cookieB } });
      const groupDownload = await fetch(`${baseUrl}/api/files/${groupUpload.data.attachment.id}`, { headers: { cookie: simulationUsers[0].cookie } });
      assert.equal(directDownload.status, 200);
      assert.equal(groupDownload.status, 200);
      assert.equal(Buffer.from(await directDownload.arrayBuffer()).toString(), 'Fichier partagé dans la conversation privée.');
      assert.deepEqual(Buffer.from(await groupDownload.arrayBuffer()), photoBytes);
      for (const participant of groupParticipants) {
        const download = await fetch(`${baseUrl}/api/files/${groupUpload.data.attachment.id}`, {
          headers: { cookie: participant.cookie }
        });
        assert.equal(download.status, 200, `${participant.name} should access the shared photo`);
        assert.deepEqual(Buffer.from(await download.arrayBuffer()), photoBytes);
      }
      assert.equal((await request(baseUrl, `/api/files/${groupUpload.data.attachment.id}`, {
        cookie: simulationUsers[1].cookie
      })).response.status, 404, 'participants outside the group must not access its files');

      const audioInvitee = clientB;
      clientA.send({ type: 'call-invite', to: welcomeB.selfId, mode: 'audio' });
      assert.equal((await audioInvitee.waitFor(message => message.type === 'signal' && message.data.invite && message.data.mode === 'audio')).data.mode, 'audio');
      audioInvitee.send({ type: 'signal', to: welcomeA.selfId, data: { accepted: true, mode: 'audio' } });
      assert.equal((await clientA.waitFor(message => message.type === 'signal' && message.data.accepted)).data.mode, 'audio');

      const videoPairs = [];
      for (let left = 0; left < groupClients.length; left++) {
        for (let right = left + 1; right < groupClients.length; right++) {
          const caller = groupClients[left];
          const recipient = groupClients[right];
          caller.client.send({ type: 'call-invite', to: recipient.selfId, mode: 'video' });
          const invitation = await recipient.client.waitFor(message =>
            message.type === 'signal' && message.data.invite && message.data.mode === 'video'
          );
          assert.equal(invitation.from, caller.selfId);
          recipient.client.send({ type: 'signal', to: caller.selfId, data: { accepted: true, mode: 'video' } });
          await caller.client.waitFor(message =>
            message.type === 'signal' && message.from === recipient.selfId && message.data.accepted
          );
          const offer = { type: 'offer', sdp: `simulated-offer-${left}-${right}` };
          caller.client.send({ type: 'signal', to: recipient.selfId, data: { description: offer } });
          const receivedOffer = await recipient.client.waitFor(message =>
            message.type === 'signal' && message.from === caller.selfId && message.data.description?.type === 'offer'
          );
          assert.equal(receivedOffer.data.description.sdp, offer.sdp);
          recipient.client.send({ type: 'signal', to: caller.selfId, data: { description: { type: 'answer', sdp: `simulated-answer-${left}-${right}` } } });
          await caller.client.waitFor(message =>
            message.type === 'signal' && message.from === recipient.selfId && message.data.description?.type === 'answer'
          );
          videoPairs.push(`${caller.name} ↔ ${recipient.name}`);
        }
      }
      assert.equal(videoPairs.length, 10, 'a five-person mesh has ten signaling peer pairs');

      clientA.send({ type: 'switch-room', room: `group:${pendingGroupId}` });
      await clientA.waitFor(message => message.type === 'welcome' && message.room === `group:${pendingGroupId}`);
      clientA.send({ type: 'chat', text: 'groupe-secret-sous-approbation' });
      await clientA.waitFor(message => message.type === 'message' && message.message.text === 'groupe-secret-sous-approbation');
      const memberSearch = await request(baseUrl, '/api/messages/search?q=groupe-secret-sous-approbation', { cookie: cookieA });
      const nonMemberSearch = await request(baseUrl, '/api/messages/search?q=groupe-secret-sous-approbation', { cookie: cookieC });
      assert.ok(memberSearch.data.results.some(message => message.room === `group:${pendingGroupId}`));
      assert.equal(nonMemberSearch.data.results.length, 0, 'non-members must not search pending group content');
    });
  } finally {
    for (const socket of sockets) socket.close();
    if (server && server.exitCode === null) {
      server.kill('SIGTERM');
      await Promise.race([once(server, 'exit'), new Promise(resolve => setTimeout(resolve, 2000))]);
    }
    await fs.rm(dataDir, { recursive: true, force: true });
  }
});
