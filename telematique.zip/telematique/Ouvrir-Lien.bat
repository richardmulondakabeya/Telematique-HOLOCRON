@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Ouvrir-Lien.ps1"
if errorlevel 1 (
  echo.
  echo Impossible de demarrer Lien. Verifiez que Node.js est installe.
  pause
)
