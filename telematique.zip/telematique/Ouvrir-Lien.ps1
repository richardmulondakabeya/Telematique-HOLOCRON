$ErrorActionPreference = 'Stop'
$projectPath = $PSScriptRoot
$port = 3000
$lienAlreadyRunning = $false

for ($candidate = 3000; $candidate -le 3010; $candidate++) {
  try {
    $response = Invoke-RestMethod -Uri "http://127.0.0.1:$candidate/health" -TimeoutSec 1
    if ($response.ok -eq $true) {
      $port = $candidate
      $lienAlreadyRunning = $true
      break
    }
  } catch { }

  $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $candidate)
  try {
    $listener.Start()
    $listener.Stop()
    $port = $candidate
    break
  } catch {
    $listener.Stop()
  }
}

if (-not $lienAlreadyRunning) {
  $env:PORT = [string]$port
  Start-Process -FilePath 'node' -ArgumentList 'server.js' -WorkingDirectory $projectPath -WindowStyle Hidden

  $ready = $false
  for ($attempt = 0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Milliseconds 500
    try {
      $response = Invoke-RestMethod -Uri "http://127.0.0.1:$port/health" -TimeoutSec 1
      if ($response.ok -eq $true) { $ready = $true; break }
    } catch { }
  }
  if (-not $ready) {
    throw 'Le serveur Lien ne démarre pas. Vérifiez que Node.js est installé.'
  }
}

Start-Process "http://localhost:$port"
