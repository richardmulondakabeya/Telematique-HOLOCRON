const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');

const root = __dirname;
const dataDir = path.resolve(process.env.DATA_DIR || root);
const requestedPort = Number(process.env.PORT || 3000);
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
const peers = new Map();
const sessions = new Map();
const userFile = path.join(dataDir, 'users.json');
const messageFile = path.join(dataDir, 'messages.json');
const groupFile = path.join(dataDir, 'groups.json');
const attachmentFile = path.join(dataDir, 'attachments.json');
const uploadDir = path.join(dataDir, 'uploads');
const messageLimit = 500;
const uploadLimit = 50 * 1024 * 1024;
fs.mkdirSync(dataDir, { recursive: true });
const iceServers = (() => {
  const raw = process.env.ICE_SERVERS_JSON;
  if (!raw) return [{ urls: 'stun:stun.l.google.com:19302' }];
  let configured;
  try { configured = JSON.parse(raw); } catch { throw new Error('ICE_SERVERS_JSON must be valid JSON.'); }
  if (!Array.isArray(configured) || configured.length > 10 || configured.some(server => {
    if (!server || typeof server !== 'object' || Array.isArray(server)) return true;
    const urls = Array.isArray(server.urls) ? server.urls : [server.urls];
    return !urls.length || urls.some(url => typeof url !== 'string' || !/^(stun|stuns|turn|turns):/i.test(url))
      || (server.username !== undefined && typeof server.username !== 'string')
      || (server.credential !== undefined && typeof server.credential !== 'string');
  })) throw new Error('ICE_SERVERS_JSON must be an array of valid ICE server objects.');
  return configured;
})();
const fileTypes = {
  '.avif': 'image/avif', '.bmp': 'image/bmp', '.gif': 'image/gif',
  '.jpeg': 'image/jpeg', '.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp',
  '.pdf': 'application/pdf', '.txt': 'text/plain', '.csv': 'text/csv', '.md': 'text/markdown',
  '.doc': 'application/msword', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.ppt': 'application/vnd.ms-powerpoint', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.odt': 'application/vnd.oasis.opendocument.text', '.ods': 'application/vnd.oasis.opendocument.spreadsheet', '.odp': 'application/vnd.oasis.opendocument.presentation',
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.oga': 'audio/ogg', '.weba': 'audio/webm', '.m4a': 'audio/mp4', '.aac': 'audio/aac', '.flac': 'audio/flac',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.m4v': 'video/x-m4v', '.avi': 'video/x-msvideo'
};
let accounts = {};
try { accounts = JSON.parse(fs.readFileSync(userFile, 'utf8')); } catch { accounts = {}; }
let history = {};
try { history = JSON.parse(fs.readFileSync(messageFile, 'utf8')); } catch { history = {}; }
let groups = [];
try { groups = JSON.parse(fs.readFileSync(groupFile, 'utf8')); } catch { groups = []; }
let attachments = {};
try { attachments = JSON.parse(fs.readFileSync(attachmentFile, 'utf8')); } catch { attachments = {}; }
function cookieToken(req) { return (req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('lien_session='))?.slice(13); }
function accountFrom(req) { const id = sessions.get(cookieToken(req)); return id ? accounts[id] : null; }
function json(res, code, data) { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(data)); }
async function authRoute(req, res, pathname) {
  if (pathname === '/api/messages/search' && req.method === 'GET') {
    const user = accountFrom(req);
    if (!user) return json(res, 401, { error: 'Connexion requise.' });
    const query = new URL(req.url, 'http://localhost').searchParams.get('q')?.trim().toLocaleLowerCase('fr') || '';
    if (query.length < 2 || query.length > 100) return json(res, 400, { error: 'La recherche doit contenir entre 2 et 100 caractères.' });
    const results = Object.entries(history).flatMap(([room, messages]) => {
      if (!roomAllowed(user.id, room)) return [];
      const group = room.startsWith('group:') ? groups.find(item => `group:${item.id}` === room) : null;
      const otherId = room.startsWith('dm:') ? room.slice(3).split(':').find(id => id !== user.id) : null;
      const roomName = group?.name || (room === 'general' ? 'général' : otherId ? `Conversation avec ${accounts[otherId]?.name || 'un contact'}` : '');
      return messagesForUser(user.id, room)
        .filter(message => String(message.text || '').toLocaleLowerCase('fr').includes(query))
        .map(message => ({ id: message.id, room, roomName, sender: message.sender, text: message.text, timestamp: message.timestamp }));
    }).sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp)).slice(0, 50);
    return json(res, 200, { results });
  }
  if (pathname === '/api/ice-config' && req.method === 'GET') {
    if (!accountFrom(req)) return json(res, 401, { error: 'Connexion requise.' });
    res.setHeader('cache-control', 'no-store');
    return json(res, 200, { iceServers });
  }
  if (pathname === '/api/uploads' && req.method === 'POST') {
    const user = accountFrom(req);
    if (!user) return json(res, 401, { error: 'Connexion requise.' });
    const room = String(req.headers['x-room'] || '');
    if (!roomAllowed(user.id, room)) return json(res, 403, { error: 'Vous ne pouvez pas joindre un fichier à cette conversation.' });
    let originalName;
    try { originalName = decodeURIComponent(String(req.headers['x-file-name'] || '')); } catch { return json(res, 400, { error: 'Nom de fichier invalide.' }); }
    originalName = path.basename(originalName.replace(/\\/g, '/')).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 160);
    if (!originalName) return json(res, 400, { error: 'Nom de fichier invalide.' });
    const extensionCandidate = path.extname(originalName).toLowerCase();
    const extension = /^\.[a-z0-9]{1,16}$/.test(extensionCandidate) ? extensionCandidate : '';
    const mime = fileTypes[extension] || 'application/octet-stream';
    const chunks = [];
    let size = 0, oversized = false;
    for await (const part of req) {
      size += part.length;
      if (size > uploadLimit) oversized = true;
      else if (!oversized) chunks.push(part);
    }
    if (oversized) return json(res, 413, { error: 'Le fichier dépasse la limite de 50 Mo.' });
    if (!size) return json(res, 400, { error: 'Le fichier est vide.' });
    fs.mkdirSync(uploadDir, { recursive: true });
    const id = crypto.randomUUID();
    const filePath = path.join(uploadDir, `${id}${extension}`);
    const attachment = { id, name: originalName, mime, size, uploadedBy: user.id, room, createdAt: new Date().toISOString() };
    const previousMessages = history[room];
    try {
      fs.writeFileSync(filePath, Buffer.concat(chunks), { flag: 'wx' });
      attachments[id] = attachment;
      fs.writeFileSync(attachmentFile, JSON.stringify(attachments, null, 2));
      const message = { id: crypto.randomUUID(), senderId: user.id, sender: user.name, text: '', timestamp: new Date().toISOString(), receipts: {}, attachment, room };
      history[room] = [...(history[room] || []), message].slice(-messageLimit);
      fs.writeFileSync(messageFile, JSON.stringify(history));
      broadcast(room, { type: 'message', message, room });
      return json(res, 201, { attachment });
    } catch (error) {
      if (previousMessages) history[room] = previousMessages; else delete history[room];
      delete attachments[id];
      try { fs.writeFileSync(messageFile, JSON.stringify(history)); fs.writeFileSync(attachmentFile, JSON.stringify(attachments, null, 2)); fs.unlinkSync(filePath); } catch { }
      return json(res, 500, { error: 'Impossible d’enregistrer ce fichier.' });
    }
  }
  if (pathname.startsWith('/api/files/') && req.method === 'GET') {
    const user = accountFrom(req);
    if (!user) return json(res, 401, { error: 'Connexion requise.' });
    const id = pathname.slice('/api/files/'.length);
    const attachment = attachments[id];
    if (!attachment || !roomAllowed(user.id, attachment.room)) return json(res, 404, { error: 'Fichier introuvable.' });
    const filePath = path.join(uploadDir, `${attachment.id}${path.extname(attachment.name).toLowerCase()}`);
    let stat;
    try { stat = fs.statSync(filePath); } catch { return json(res, 404, { error: 'Fichier introuvable.' }); }
    const inline = attachment.mime === 'application/pdf' || attachment.mime.startsWith('image/') || attachment.mime.startsWith('audio/') || attachment.mime.startsWith('video/');
    const fallbackName = attachment.name.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
    const headers = {
      'content-type': attachment.mime, 'accept-ranges': 'bytes', 'x-content-type-options': 'nosniff',
      'cache-control': 'private, no-store',
      'content-disposition': `${inline ? 'inline' : 'attachment'}; filename="${fallbackName}"; filename*=UTF-8''${encodeURIComponent(attachment.name)}`
    };
    let start = 0, end = stat.size - 1, status = 200;
    const range = req.headers.range?.match(/^bytes=(\d*)-(\d*)$/);
    if (range) {
      if (range[1] === '' && range[2] === '') { res.writeHead(416, { 'content-range': `bytes */${stat.size}` }); res.end(); return; }
      if (range[1] === '') { const suffix = Number(range[2]); start = Math.max(0, stat.size - suffix); }
      else { start = Number(range[1]); if (range[2]) end = Math.min(Number(range[2]), end); }
      if (start >= stat.size || end < start) { res.writeHead(416, { 'content-range': `bytes */${stat.size}` }); res.end(); return; }
      status = 206;
      headers['content-range'] = `bytes ${start}-${end}/${stat.size}`;
    }
    headers['content-length'] = end - start + 1;
    res.writeHead(status, headers);
    fs.createReadStream(filePath, { start, end }).pipe(res);
    return;
  }
  if (pathname === '/api/groups' || pathname.startsWith('/api/groups/') || pathname === '/api/users') {
    const user = accountFrom(req);
    if (!user) return json(res, 401, { error: 'Connexion requise.' });
    if (pathname === '/api/users' && req.method === 'GET') return json(res, 200, { users: Object.values(accounts).filter(a => a.id !== user.id).map(a => ({ id: a.id, name: a.name })) });
    if (pathname === '/api/groups' && req.method === 'GET') return json(res, 200, {
      groups: groups.filter(g => g.memberIds.includes(user.id)).map(group => {
        const { pendingMemberIds, ...safeGroup } = group;
        return { ...safeGroup, pendingRequestCount: group.createdBy === user.id ? (pendingMemberIds || []).length : 0 };
      })
    });
    if (pathname === '/api/groups/requests' && req.method === 'GET') return json(res, 200, {
      requests: groups.filter(group => group.createdBy === user.id).flatMap(group =>
        (group.pendingMemberIds || []).filter(userId => accounts[userId]).map(userId => ({
          groupId: group.id,
          groupName: group.name,
          userId,
          userName: accounts[userId].name
        }))
      )
    });
    if (pathname === '/api/groups/discover' && req.method === 'GET') return json(res, 200, {
      groups: groups.filter(group => group.visibility === 'public' && !group.memberIds.includes(user.id))
        .map(group => ({
          id: group.id,
          name: group.name,
          memberCount: group.memberIds.length,
          requestPending: (group.pendingMemberIds || []).includes(user.id)
        }))
    });
    if (pathname === '/api/groups' && req.method === 'POST') {
      let raw = ''; for await (const part of req) { raw += part; if (raw.length > 8192) return json(res, 413, { error: 'Requête trop volumineuse.' }); }
      let body; try { body = JSON.parse(raw); } catch { return json(res, 400, { error: 'Formulaire invalide.' }); }
      const name = String(body.name || '').trim().replace(/\s+/g, ' ').slice(0, 40);
      const memberIds = [...new Set([user.id, ...(Array.isArray(body.memberIds) ? body.memberIds.filter(id => typeof id === 'string') : [])])];
      if (name.length < 2) return json(res, 400, { error: 'Le nom du groupe doit contenir au moins 2 caractères.' });
      const visibility = body.visibility === 'public' ? 'public' : 'private';
      if (visibility === 'private' && memberIds.length < 2) return json(res, 400, { error: 'Sélectionnez au moins un autre membre pour un groupe privé.' });
      if (memberIds.length > 50 || memberIds.some(id => !accounts[id])) return json(res, 400, { error: 'La liste des membres est invalide.' });
      const group = { id: crypto.randomUUID(), name, createdBy: user.id, memberIds, pendingMemberIds: [], visibility, createdAt: new Date().toISOString() };
      groups.push(group);
      try { fs.writeFileSync(groupFile, JSON.stringify(groups, null, 2)); } catch { groups.pop(); return json(res, 500, { error: 'Impossible d’enregistrer le groupe.' }); }
      for (const peer of peers.values()) if (group.memberIds.includes(peer.userId)) send(peer, { type: 'users', users: roster(peer.room) });
      return json(res, 201, { group });
    }
    if (pathname.startsWith('/api/groups/') && req.method === 'PATCH') {
      const id = decodeURIComponent(pathname.slice('/api/groups/'.length));
      const group = groups.find(item => item.id === id);
      if (!group) return json(res, 404, { error: 'Groupe introuvable.' });
      if (group.createdBy !== user.id) return json(res, 403, { error: 'Seul le créateur peut modifier la confidentialité.' });
      let raw = ''; for await (const part of req) { raw += part; if (raw.length > 1024) return json(res, 413, { error: 'Requête trop volumineuse.' }); }
      let body; try { body = JSON.parse(raw); } catch { return json(res, 400, { error: 'Formulaire invalide.' }); }
      if (!body || !['private', 'public'].includes(body.visibility)) return json(res, 400, { error: 'Visibilité invalide.' });
      const previousVisibility = group.visibility;
      const previousPending = group.pendingMemberIds || [];
      group.visibility = body.visibility;
      if (body.visibility === 'private') group.pendingMemberIds = [];
      try { fs.writeFileSync(groupFile, JSON.stringify(groups, null, 2)); } catch {
        group.visibility = previousVisibility;
        group.pendingMemberIds = previousPending;
        return json(res, 500, { error: 'Impossible d’enregistrer la confidentialité du groupe.' });
      }
      if (body.visibility === 'private') {
        for (const requesterId of previousPending) {
          for (const peer of peers.values()) if (peer.userId === requesterId) send(peer, { type: 'group-request-updated', groupId: group.id, status: 'rejected' });
        }
      }
      return json(res, 200, { group: { id: group.id, name: group.name, visibility: group.visibility } });
    }
    if (pathname.startsWith('/api/groups/') && pathname.endsWith('/join') && req.method === 'POST') {
      const id = decodeURIComponent(pathname.slice('/api/groups/'.length, -'/join'.length));
      const group = groups.find(item => item.id === id);
      if (!group || group.visibility !== 'public') return json(res, 404, { error: 'Groupe public introuvable.' });
      if (group.memberIds.includes(user.id)) return json(res, 200, { status: 'member', group });
      group.pendingMemberIds ||= [];
      if (group.pendingMemberIds.includes(user.id)) return json(res, 200, { status: 'pending', group: { id: group.id, name: group.name } });
      if (group.memberIds.length + group.pendingMemberIds.length >= 50) return json(res, 409, { error: 'Ce groupe a atteint sa limite de membres.' });
      group.pendingMemberIds.push(user.id);
      try { fs.writeFileSync(groupFile, JSON.stringify(groups, null, 2)); } catch {
        group.pendingMemberIds.pop();
        return json(res, 500, { error: 'Impossible d’envoyer la demande.' });
      }
      for (const peer of peers.values()) if (peer.userId === group.createdBy) send(peer, { type: 'group-request', groupId: group.id, groupName: group.name });
      return json(res, 200, { status: 'pending', group: { id: group.id, name: group.name } });
    }
    const requestMatch = pathname.match(/^\/api\/groups\/([^/]+)\/requests\/([^/]+)\/(approve|reject)$/);
    if (requestMatch && req.method === 'POST') {
      const [, rawGroupId, rawUserId, action] = requestMatch;
      const group = groups.find(item => item.id === decodeURIComponent(rawGroupId));
      if (!group) return json(res, 404, { error: 'Groupe introuvable.' });
      if (group.createdBy !== user.id) return json(res, 403, { error: 'Seul le créateur peut traiter les demandes.' });
      const requesterId = decodeURIComponent(rawUserId);
      group.pendingMemberIds ||= [];
      const pendingIndex = group.pendingMemberIds.indexOf(requesterId);
      if (pendingIndex < 0) return json(res, 404, { error: 'Demande introuvable.' });
      if (action === 'approve' && group.memberIds.length >= 50) return json(res, 409, { error: 'Ce groupe a atteint sa limite de membres.' });
      const addMember = action === 'approve' && !group.memberIds.includes(requesterId);
      group.pendingMemberIds.splice(pendingIndex, 1);
      if (addMember) group.memberIds.push(requesterId);
      try { fs.writeFileSync(groupFile, JSON.stringify(groups, null, 2)); } catch {
        group.pendingMemberIds.splice(pendingIndex, 0, requesterId);
        if (addMember) group.memberIds.pop();
        return json(res, 500, { error: 'Impossible d’enregistrer la réponse à la demande.' });
      }
      for (const peer of peers.values()) if (peer.userId === requesterId) send(peer, { type: 'group-request-updated', groupId: group.id, status: action === 'approve' ? 'approved' : 'rejected' });
      return json(res, 200, { status: action === 'approve' ? 'approved' : 'rejected' });
    }
    if (pathname.startsWith('/api/groups/') && req.method === 'DELETE') {
      const id = decodeURIComponent(pathname.slice('/api/groups/'.length));
      const index = groups.findIndex(group => group.id === id);
      if (index < 0) return json(res, 404, { error: 'Groupe introuvable.' });
      const group = groups[index];
      if (group.createdBy !== user.id) return json(res, 403, { error: 'Seul le créateur peut supprimer ce groupe.' });
      const room = `group:${group.id}`;
      const previousHistory = history[room];
      groups.splice(index, 1);
      delete history[room];
      try {
        fs.writeFileSync(groupFile, JSON.stringify(groups, null, 2));
        fs.writeFileSync(messageFile, JSON.stringify(history));
      } catch {
        groups.splice(index, 0, group);
        if (previousHistory) history[room] = previousHistory;
        try { fs.writeFileSync(groupFile, JSON.stringify(groups, null, 2)); fs.writeFileSync(messageFile, JSON.stringify(history)); } catch { }
        return json(res, 500, { error: 'Impossible de supprimer le groupe.' });
      }
      for (const peer of peers.values()) {
        const wasMember = peer.rooms?.delete(room);
        if (!wasMember) continue;
        if (peer.room === room) {
          peer.room = 'general';
          peer.rooms.add('general');
          send(peer, { type: 'welcome', selfId: peer.id, users: roster('general'), messages: messagesForUser(peer.userId, 'general'), room: 'general', roomInfo: null });
        } else send(peer, { type: 'users', users: roster(peer.room), room: peer.room });
      }
      broadcast('general', { type: 'users', users: roster('general') });
      return json(res, 200, { ok: true });
    }
    return json(res, 405, { error: 'Méthode non autorisée.' });
  }
  if (pathname === '/api/me' && req.method === 'GET') { const a = accountFrom(req); return json(res, 200, { user: a ? { id: a.id, name: a.name } : null }); }
  if (pathname === '/api/logout' && req.method === 'POST') { sessions.delete(cookieToken(req)); res.setHeader('Set-Cookie', 'lien_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' + (req.socket.encrypted ? '; Secure' : '')); return json(res, 200, { ok: true }); }
  if (!['/api/register', '/api/login'].includes(pathname) || req.method !== 'POST') return false;
  let raw = ''; for await (const part of req) { raw += part; if (raw.length > 4096) return json(res, 413, { error: 'Requête trop volumineuse.' }); }
  let body; try { body = JSON.parse(raw); } catch { return json(res, 400, { error: 'Formulaire invalide.' }); }
  const email = String(body.email || '').trim().toLowerCase(); const password = String(body.password || '');
  if (pathname === '/api/register') {
    const name = String(body.name || '').trim().slice(0, 32);
    if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8) return json(res, 400, { error: 'Nom (2 caractères), e-mail valide et mot de passe (8 caractères minimum) requis.' });
    if (Object.values(accounts).some(a => a.email === email)) return json(res, 409, { error: 'Cette adresse e-mail est déjà inscrite.' });
    const id = crypto.randomUUID(), salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(password, salt, 64).toString('hex'); accounts[id] = { id, name, email, salt, hash, createdAt: new Date().toISOString() };
    try { fs.writeFileSync(userFile, JSON.stringify(accounts, null, 2)); } catch { delete accounts[id]; return json(res, 500, { error: 'Impossible d’enregistrer le compte.' }); }
  }
  const user = Object.values(accounts).find(a => a.email === email);
  if (!user || !crypto.timingSafeEqual(Buffer.from(crypto.scryptSync(password, user.salt, 64).toString('hex')), Buffer.from(user.hash))) return json(res, 401, { error: 'Adresse e-mail ou mot de passe incorrect.' });
  const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, user.id);
  if (pathname === '/api/register') for (const peer of peers.values()) send(peer, { type: 'directory-update' });
  res.setHeader('Set-Cookie', `lien_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000` + (req.socket.encrypted ? '; Secure' : ''));
  return json(res, 200, { user: { id: user.id, name: user.name } });
}
function send(peer, data) { if (!peer.closed) peer.socket.write(frame(JSON.stringify(data))); }
function frame(text) {
  const body = Buffer.from(text); let header;
  if (body.length < 126) { header = Buffer.from([0x81, body.length]); }
  else if (body.length < 65536) { header = Buffer.alloc(4); header[0] = 0x81; header[1] = 126; header.writeUInt16BE(body.length, 2); }
  else { header = Buffer.alloc(10); header[0] = 0x81; header[1] = 127; header.writeBigUInt64BE(BigInt(body.length), 2); }
  return Buffer.concat([header, body]);
}
function roster(room) {
  const online = new Map();
  for (const peer of peers.values()) {
    if (!peer.rooms?.has(room)) continue;
    const current = online.get(peer.userId);
    if (!current || (peer.room === room && current.room !== room)) online.set(peer.userId, peer);
  }
  return [...online.values()].map(p => ({ id: p.id, userId: p.userId, name: p.name, status: 'online', call: p.call }));
}
function globalPresence() {
  const online = new Map();
  for (const peer of peers.values()) {
    const current = online.get(peer.userId);
    if (!current || (peer.call && !current.call)) online.set(peer.userId, peer);
  }
  return [...online.values()].map(peer => ({ userId: peer.userId, name: peer.name, status: 'online', call: peer.call }));
}
function broadcastPresence() {
  const data = { type: 'presence', users: globalPresence() };
  for (const peer of peers.values()) send(peer, data);
}
function broadcast(room, data) { for (const p of peers.values()) if (p.rooms?.has(room) && (data.type !== 'users' || p.room === room)) send(p, { ...data, room }); }
function messagesForUser(userId, room) {
  const createdAt = accounts[userId]?.createdAt;
  return (history[room] || []).filter(message => !createdAt || Date.parse(message.timestamp) > Date.parse(createdAt));
}
function directRoom(a, b) { return `dm:${[a, b].sort().join(':')}`; }
function roomAllowed(userId, room) {
  if (room === 'lobby') return true;
  if (room === 'general') return true;
  if (typeof room === 'string' && room.startsWith('group:')) {
    const group = groups.find(item => item.id === room.slice(6));
    return Boolean(group && group.memberIds.includes(userId));
  }
  if (typeof room !== 'string' || !room.startsWith('dm:')) return false;
  const ids = room.slice(3).split(':');
  return ids.length === 2 && ids.includes(userId) && ids[0] !== ids[1];
}
function enterRoom(p, room) {
  if (!roomAllowed(p.userId, room)) return;
  const previous = p.room;
  for (const peer of peers.values()) if ((peer === p || peer.room) && roomAllowed(peer.userId, room)) peer.rooms.add(room);
  p.room = room;
  const group = room.startsWith('group:') ? groups.find(item => `group:${item.id}` === room) : null;
  send(p, { type: 'welcome', selfId: p.id, users: roster(room), onlineUsers: globalPresence(), messages: messagesForUser(p.userId, room), room, roomInfo: group ? { id: group.id, name: group.name } : null });
  if (previous) broadcast(previous, { type: 'users', users: roster(previous) });
  broadcast(room, { type: 'users', users: roster(room) });
  if (!previous) broadcastPresence();
}
function remove(p) { if (p.closed) return; p.closed = true; peers.delete(p.id); for (const room of p.rooms || []) broadcast(room, { type: 'users', users: roster(room) }); broadcastPresence(); }
function parseFrames(peer, chunk) {
  peer.buffer = Buffer.concat([peer.buffer, chunk]);
  while (peer.buffer.length >= 2) {
    const b0 = peer.buffer[0], b1 = peer.buffer[1]; let len = b1 & 127, offset = 2;
    if (len === 126) { if (peer.buffer.length < 4) return; len = peer.buffer.readUInt16BE(2); offset = 4; }
    else if (len === 127) { if (peer.buffer.length < 10) return; const big = peer.buffer.readBigUInt64BE(2); if (big > 65536n) return remove(peer); len = Number(big); offset = 10; }
    const masked = Boolean(b1 & 128); if (!masked || len > 65536) return remove(peer);
    if (peer.buffer.length < offset + 4 + len) return;
    const mask = peer.buffer.subarray(offset, offset + 4); offset += 4;
    const body = Buffer.from(peer.buffer.subarray(offset, offset + len)); peer.buffer = peer.buffer.subarray(offset + len);
    for (let i = 0; i < body.length; i++) body[i] ^= mask[i % 4];
    const opcode = b0 & 15;
    if (opcode === 8) { peer.socket.end(Buffer.from([0x88, 0])); remove(peer); return; }
    if (opcode === 9) { peer.socket.write(Buffer.from([0x8a, body.length, ...body])); continue; }
    if (opcode === 10) { peer.lastPong = Date.now(); continue; }
    if (opcode !== 1) continue;
    try { handle(peer, JSON.parse(body.toString('utf8'))); } catch { send(peer, { type: 'error', message: 'Message invalide.' }); }
  }
}
function handle(p, msg) {
  if (!msg || typeof msg.type !== 'string') return;
  if (msg.type === 'join' && !p.room) {
    p.call = null;
    enterRoom(p, typeof msg.room === 'string' && roomAllowed(p.userId, msg.room) ? msg.room : 'general'); return;
  }
  if (msg.type === 'switch-room' && typeof msg.withUser === 'string') { enterRoom(p, directRoom(p.userId, msg.withUser)); return; }
  if (msg.type === 'switch-room' && typeof msg.room === 'string') { enterRoom(p, msg.room); return; }
  if (!p.room) return;
  if (p.room === 'lobby') return;
  if (msg.type === 'chat') {
    const text = String(msg.text || '').trim().slice(0, 2000); if (!text) return;
    const message = { id: crypto.randomUUID(), senderId: p.userId, sender: p.name, text, timestamp: new Date().toISOString(), receipts: {} };
    history[p.room] = [...(history[p.room] || []), message].slice(-messageLimit);
    try { fs.writeFileSync(messageFile, JSON.stringify(history)); } catch (error) { console.error('Impossible d’enregistrer les messages:', error.message); }
    broadcast(p.room, { type: 'message', message: { ...message, room: p.room }, room: p.room });
  } else if (msg.type === 'receipt' && typeof msg.messageId === 'string' && typeof msg.room === 'string' && ['delivered', 'read'].includes(msg.status)) {
    if (!p.rooms?.has(msg.room) || !roomAllowed(p.userId, msg.room) || !msg.room.startsWith('dm:')) return;
    const message = (history[msg.room] || []).find(item => item.id === msg.messageId);
    if (!message || message.senderId === p.userId) return;
    message.receipts ||= {};
    if (message.receipts[p.userId] !== 'read') message.receipts[p.userId] = msg.status;
    try { fs.writeFileSync(messageFile, JSON.stringify(history)); } catch (error) { console.error('Impossible d’enregistrer les accusés:', error.message); }
    broadcast(msg.room, { type: 'message', message: { receipt: true, messageId: msg.messageId, status: message.receipts[p.userId], by: p.userId, room: msg.room }, room: msg.room });
  } else if (msg.type === 'call-state') {
    p.call = ['audio', 'video'].includes(msg.mode) ? msg.mode : null;
    broadcast(p.room, { type: 'users', users: roster(p.room) });
    broadcastPresence();
  } else if (msg.type === 'call-invite' && typeof msg.to === 'string' && ['audio', 'video'].includes(msg.mode)) {
    const target = peers.get(msg.to);
    if (target && target.rooms?.has(p.room) && roomAllowed(target.userId, p.room)) {
      send(target, { type: 'signal', from: p.id, fromName: p.name, data: { invite: true, mode: msg.mode, room: p.room } });
    }
  } else if (msg.type === 'signal' && typeof msg.to === 'string' && msg.data && JSON.stringify(msg.data).length < 65536) {
    const target = peers.get(msg.to); if (target && target.rooms?.has(p.room) && roomAllowed(target.userId, p.room)) send(target, { type: 'signal', from: p.id, fromName: p.name, data: msg.data });
  }
}
const handler = (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) { authRoute(req, res, url.pathname).then(result => { if (result === false) json(res, 404, { error: 'Introuvable.' }); }).catch(() => json(res, 500, { error: 'Erreur serveur.' })); return; }
  if (url.pathname === '/health') { res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"ok":true}'); return; }
  const requested = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const file = path.resolve(root, `.${requested}`);
  if (!file.startsWith(root + path.sep)) { res.writeHead(403); res.end('Forbidden'); return; }
  if (file.startsWith(uploadDir + path.sep) || ['users.json', 'messages.json', 'groups.json', 'attachments.json', 'lien-https.pfx', 'lien-https-password.dpapi'].includes(path.basename(file))) { res.writeHead(403); res.end('Forbidden'); return; }
  fs.readFile(file, (err, data) => { if (err) { res.writeHead(404); res.end('Not found'); return; } res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' }); res.end(data); });
};
const tlsEnabled = Boolean(process.env.TLS_PFX || (process.env.TLS_CERT && process.env.TLS_KEY));
let server;
if (process.env.TLS_PFX) server = https.createServer({ pfx: fs.readFileSync(process.env.TLS_PFX), passphrase: process.env.TLS_PFX_PASSWORD || '' }, handler);
else if (process.env.TLS_CERT && process.env.TLS_KEY) server = https.createServer({ cert: fs.readFileSync(process.env.TLS_CERT), key: fs.readFileSync(process.env.TLS_KEY) }, handler);
else server = http.createServer(handler);
const localHttpPort = Number(process.env.LOCAL_HTTP_PORT || 3002);
const localHttpServer = tlsEnabled ? http.createServer(handler) : null;
const upgradeHandler = (req, socket) => {
  if (req.url !== '/ws' || !req.headers['sec-websocket-key']) { socket.destroy(); return; }
  const account = accountFrom(req);
  if (!account) { socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const p = { id: crypto.randomUUID(), userId: account.id, socket, buffer: Buffer.alloc(0), room: null, rooms: new Set(), name: account.name, call: null, lastPong: Date.now(), closed: false };
  peers.set(p.id, p); socket.on('data', b => parseFrames(p, b)); socket.on('close', () => remove(p)); socket.on('error', () => remove(p));
};
server.on('upgrade', upgradeHandler);
if (localHttpServer) {
  localHttpServer.on('upgrade', upgradeHandler);
  localHttpServer.on('error', error => console.error(`HTTP localhost indisponible sur le port ${localHttpPort}: ${error.message}`));
  localHttpServer.listen(localHttpPort, '127.0.0.1', () => console.log(`Accès local partagé sur http://localhost:${localHttpPort}`));
}
function listenOnAvailablePort(candidate) {
  server.once('error', error => {
    if ((error.code === 'EADDRINUSE' || error.code === 'EACCES') && !process.env.PORT && candidate < requestedPort + 10) {
      listenOnAvailablePort(candidate + 1);
      return;
    }
    console.error(`Impossible de démarrer Lien sur le port ${candidate}: ${error.message}`);
    process.exitCode = 1;
  });
  server.listen(candidate, '0.0.0.0', () => {
    const scheme = process.env.TLS_PFX || process.env.TLS_CERT ? 'https' : 'http';
    const lanAddress = Object.values(os.networkInterfaces()).flat().find(address => address && address.family === 'IPv4' && !address.internal)?.address;
    const port = server.address().port;
    console.log(`Lien prêt sur ${scheme}://localhost:${port}${lanAddress ? ` et ${scheme}://${lanAddress}:${port}` : ''}`);
  });
}
listenOnAvailablePort(requestedPort);
const heartbeat = setInterval(() => {
  const now = Date.now();
  for (const peer of peers.values()) {
    if (now - peer.lastPong > 45000) { peer.socket.destroy(); remove(peer); continue; }
    if (!peer.closed) peer.socket.write(Buffer.from([0x89, 0]));
  }
}, 15000);
heartbeat.unref();
