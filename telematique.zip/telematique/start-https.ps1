$ErrorActionPreference = 'Stop'

$ip = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
  Where-Object { $_.OperationalStatus -eq [System.Net.NetworkInformation.OperationalStatus]::Up } |
  ForEach-Object { $_.GetIPProperties() } |
  Where-Object { $_.GatewayAddresses.Count -gt 0 } |
  ForEach-Object { $_.UnicastAddresses } |
  Where-Object { $_.Address.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork -and -not [System.Net.IPAddress]::IsLoopback($_.Address) } |
  Select-Object -First 1 -ExpandProperty Address | ForEach-Object { $_.IPAddressToString }
if (-not $ip) { throw 'Impossible de trouver une adresse IPv4 locale. Connectez ce PC au réseau puis relancez le script.' }

$certPath = Join-Path $PSScriptRoot 'lien-https.pfx'
$publicPath = Join-Path $PSScriptRoot 'lien-certificat.cer'
$passwordPath = Join-Path $PSScriptRoot 'lien-https-password.dpapi'
$cert = $null
$plainPassword = $null
if ((Test-Path $certPath) -and (Test-Path $publicPath) -and (Test-Path $passwordPath)) {
  $securePassword = Get-Content $passwordPath -Raw | ConvertTo-SecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
  try { $plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
  $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($publicPath)
  $sanText = ($cert.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' } | ForEach-Object { $_.Format($false) }) -join ';'
  if ($cert.NotAfter -le (Get-Date) -or $sanText -notmatch [regex]::Escape($ip)) { $cert = $null }
}
if (-not $cert) {
  $rsa = [System.Security.Cryptography.RSA]::Create(2048)
  $subject = [System.Security.Cryptography.X509Certificates.X500DistinguishedName]::new("CN=$ip")
  $request = [System.Security.Cryptography.X509Certificates.CertificateRequest]::new($subject, $rsa, [System.Security.Cryptography.HashAlgorithmName]::SHA256, [System.Security.Cryptography.RSASignaturePadding]::Pkcs1)
  $request.CertificateExtensions.Add([System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension]::new($false, $false, 0, $true))
  $keyUsage = [System.Security.Cryptography.X509Certificates.X509KeyUsageFlags]::DigitalSignature -bor [System.Security.Cryptography.X509Certificates.X509KeyUsageFlags]::KeyEncipherment
  $request.CertificateExtensions.Add([System.Security.Cryptography.X509Certificates.X509KeyUsageExtension]::new($keyUsage, $true))
  $oids = [System.Security.Cryptography.OidCollection]::new()
  $oids.Add([System.Security.Cryptography.Oid]::new('1.3.6.1.5.5.7.3.1')) | Out-Null
  $eku = [System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension]::new($oids, $false)
  $request.CertificateExtensions.Add($eku)
  $san = [System.Security.Cryptography.X509Certificates.SubjectAlternativeNameBuilder]::new()
  $san.AddDnsName('localhost')
  $san.AddIpAddress([System.Net.IPAddress]::Parse($ip))
  $san.AddIpAddress([System.Net.IPAddress]::Parse('127.0.0.1'))
  $request.CertificateExtensions.Add($san.Build())
  $cert = $request.CreateSelfSigned((Get-Date).AddMinutes(-5), (Get-Date).AddYears(2))
  [byte[]]$randomBytes = New-Object byte[] 32
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($randomBytes)
  $plainPassword = [Convert]::ToBase64String($randomBytes)
  $securePassword = ConvertTo-SecureString -String $plainPassword -AsPlainText -Force
  [IO.File]::WriteAllBytes($certPath, $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx, $plainPassword))
  [IO.File]::WriteAllBytes($publicPath, $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert))
  $securePassword | ConvertFrom-SecureString | Set-Content -Path $passwordPath -NoNewline
  $rsa.Dispose()
}
try {
  $rootStore = [System.Security.Cryptography.X509Certificates.X509Store]::new([System.Security.Cryptography.X509Certificates.StoreName]::Root, [System.Security.Cryptography.X509Certificates.StoreLocation]::CurrentUser)
  $rootStore.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
  $rootStore.Add($cert)
  $rootStore.Close()
  Write-Host 'Certificat ajouté aux autorités approuvées de ce compte Windows.'
} catch { Write-Warning 'Import automatique du certificat refusé par Windows. Sur ce PC, ouvrez lien-certificat.cer et choisissez Installer le certificat > Utilisateur actuel > Autorités de certification racines de confiance.' }

$env:TLS_PFX = $certPath
$env:TLS_PFX_PASSWORD = $plainPassword
$env:LOCAL_HTTP_PORT = '3002'
if (Test-Path Env:PORT) { Remove-Item Env:PORT }
Write-Host 'Les accès HTTPS du réseau et HTTP local partageront la même présence et les mêmes conversations.'
Write-Host 'Lien HTTP local : http://localhost:3002'
Write-Host "Adresse réseau : https://${ip} (ajoutez le port indiqué ci-dessous)."
Write-Host "Certificat à approuver sur les autres appareils : $publicPath"
Write-Host 'Gardez cette fenêtre ouverte pendant l’utilisation de Lien.'
& node (Join-Path $PSScriptRoot 'server.js')
